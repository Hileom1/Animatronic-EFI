# Security Policy

## Supported Versions

Current version as reported in README.md
        |

## Reporting a Vulnerability

email robert@tideys.co.uk with details of vulnerability found and any suggested remedies.

You will receive an email response (typically within 48 hours describing action that will be taken
